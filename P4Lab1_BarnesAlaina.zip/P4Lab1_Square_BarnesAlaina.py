# Alaina Barnes
# P4Lab1
# 7/6/24
# Making a square with turtle graphics and for loop

#import turtle and create window for turtle to be drawn. name your shape.

import turtle
win = turtle.Screen()
lilguy = turtle.Turtle()

#customize how the turtle is drawn by changing color, line size, and icon.

lilguy.pensize(5)
lilguy.shape('turtle')
lilguy.pencolor('purple')

#create for loop specificing how far to walk and what degree angle to turn

for i in (1,2,3,4):
 lilguy.forward(100)
 lilguy.left(90)



#end commands
win.mainloop()
